import pandas as pd
import json
import statistics
import os

# --- CONFIGURATION ---
DATASETS = [
    ("nutrition_dataset.csv", True, "original"),
    ("Indian_Food_Nutrition_Processed.csv", True, "indian"),
    ("daily_food_nutrition_filled.csv", True, "daily")
]


MEAL_COLS = ["Breakfast Suggestion", "Lunch Suggestion", "Dinner Suggestion", "Snack Suggestion"]
OUTPUT_JSON = "meal_database.json"
OUTLIER_MIN = 50
OUTLIER_MAX = 1500

meal_db = {}
calorie_outliers = []

# --- Helpers ---
def safe_float(val):
    try:
        return float(str(val).strip())
    except:
        return 0.0

def estimate_calories(protein, carbs, fat):
    return round((protein * 4) + (carbs * 4) + (fat * 9), 2)

def med(nums):
    try:
        return round(statistics.median(nums), 2)
    except:
        return round(sum(nums)/len(nums), 2)

def normalize_meal_type(meal_type):
    mt = str(meal_type).lower()
    if "breakfast" in mt: return "breakfast"
    if "lunch" in mt: return "lunch"
    if "dinner" in mt: return "dinner"
    if "snack" in mt: return "snack"
    return "unspecified"

def infer_diet_tags(protein, carbs, fat, fiber, sodium, calories):
    try:
        fat_pct = (fat * 9) / calories
        carb_pct = (carbs * 4) / calories
    except ZeroDivisionError:
        return ["balanced"]
    tags = []
    if fat_pct > 0.5 and carbs < 100: tags.append("keto")
    if fat_pct < 0.25:                tags.append("low-fat")
    if carb_pct < 0.3:                tags.append("low-carb")
    if 0.3 <= fat_pct <= 0.4 and 0.4 <= carb_pct: tags.append("balanced")
    if sodium < 300 and fiber > 5:    tags.append("dash")
    return tags or ["balanced"]

# --- Process each dataset ---
for filename, has_calories, source in DATASETS:
    if not os.path.exists(filename):
        print(f"⚠️ Skipping missing file: {filename}")
        continue

    df = pd.read_csv(filename)
    df.fillna(0, inplace=True)

    if source == "original":
        for _, row in df.iterrows():
            diet = str(row.get("Dietary Preference", "Omnivore")).strip().capitalize()
            diseases = [d.strip() for d in str(row.get("Disease", "")).split(",") if d.strip()]
            for col in MEAL_COLS:
                name = str(row.get(col, "")).strip()
                if not name: continue
                meal_type = col.split()[0].lower()
                protein = safe_float(row.get("Protein"))
                carbs   = safe_float(row.get("Carbohydrates"))
                fat     = safe_float(row.get("Fat"))
                fiber   = safe_float(row.get("Fiber"))
                sugar   = safe_float(row.get("Sugar"))
                sodium  = safe_float(row.get("Sodium"))
                cholesterol = safe_float(row.get("Cholesterol"))
                calories = safe_float(row.get("Calories")) or estimate_calories(protein, carbs, fat)

                tags = infer_diet_tags(protein, carbs, fat, fiber, sodium, calories)

                entry = meal_db.setdefault(name, {
                    "name": name,
                    "meal_type": meal_type,
                    "dietary_preference": diet,
                    "tags": set(),
                    "health_conditions": set(diseases),
                    "source": source,
                    "calories": [],
                    "protein": [],
                    "carbs": [],
                    "fat": [],
                    "sugar": [],
                    "sodium": [],
                    "fiber": [],
                    "cholesterol": []
                })

                entry["tags"].update(tags)
                entry["calories"].append(calories)
                entry["protein"].append(protein)
                entry["carbs"].append(carbs)
                entry["fat"].append(fat)
                entry["sugar"].append(sugar)
                entry["sodium"].append(sodium)
                entry["fiber"].append(fiber)
                entry["cholesterol"].append(cholesterol)

    else:
        for _, row in df.iterrows():
            name = str(row.get("Recipe_name") or row.get("Food_Item") or row.get("Dish") or row.get("Meal") or "").strip()
            if not name: continue

            meal_type = normalize_meal_type(row.get("Meal_Type") or row.get("Category") or "unspecified")
            protein = safe_float(row.get("Protein(g)", row.get("Protein", 0)))
            carbs   = safe_float(row.get("Carbs(g)", row.get("Carbohydrates", row.get("Carbs", 0))))
            fat     = safe_float(row.get("Fat(g)", row.get("Fat", 0)))
            fiber   = safe_float(row.get("Fiber", 0))
            sugar   = safe_float(row.get("Sugar", 0))
            sodium  = safe_float(row.get("Sodium", 0))
            cholesterol = safe_float(row.get("Cholesterol", 0))
            calories = safe_float(row.get("Calories", 0)) or estimate_calories(protein, carbs, fat)

            tags = infer_diet_tags(protein, carbs, fat, fiber, sodium, calories)
            diet = str(row.get("Diet_type", "Omnivore")).capitalize()

            entry = meal_db.setdefault(name, {
                "name": name,
                "meal_type": meal_type,
                "dietary_preference": diet,
                "tags": set(),
                "health_conditions": set(),
                "source": source,
                "calories": [],
                "protein": [],
                "carbs": [],
                "fat": [],
                "sugar": [],
                "sodium": [],
                "fiber": [],
                "cholesterol": []
            })

            entry["tags"].update(tags)
            entry["calories"].append(calories)
            entry["protein"].append(protein)
            entry["carbs"].append(carbs)
            entry["fat"].append(fat)
            entry["sugar"].append(sugar)
            entry["sodium"].append(sodium)
            entry["fiber"].append(fiber)
            entry["cholesterol"].append(cholesterol)

# --- Finalize entries ---
for name, data in meal_db.items():
    data["avg_calories"] = med(data["calories"])
    data["avg_protein"]  = med(data["protein"])
    data["avg_carbs"]    = med(data["carbs"])
    data["avg_fat"]      = med(data["fat"])
    data["avg_sugar"]    = med(data["sugar"])
    data["avg_sodium"]   = med(data["sodium"])
    data["avg_fiber"]    = med(data["fiber"])
    data["avg_cholesterol"] = med(data["cholesterol"])

    if data["avg_calories"] < OUTLIER_MIN or data["avg_calories"] > OUTLIER_MAX:
        calorie_outliers.append((name, data["avg_calories"]))

    data["tags"] = sorted(data["tags"])
    data["health_conditions"] = sorted(data["health_conditions"])
    for key in ["calories", "protein", "carbs", "fat", "sugar", "sodium", "fiber", "cholesterol"]:
        del data[key]

# --- Write to JSON ---
with open(OUTPUT_JSON, "w") as f:
    json.dump(meal_db, f, indent=2)

# --- Report ---
print(f"\n✅ Generated {len(meal_db)} meals in {OUTPUT_JSON}")

if calorie_outliers:
    print("\n⚠️ Calorie outliers detected:")
    for name, c in calorie_outliers:
        print(f"  • {name}: {c} kcal")
else:
    print("\nNo calorie outliers found.")
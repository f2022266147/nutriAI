import pandas as pd

# --- Calorie lookup table (you can expand this) ---
CALORIE_LOOKUP = {
    "Eggs": 78,
    "Oats": 150,
    "Apple": 95,
    "Carrot": 25,
    "Cookies": 160,
    "Quinoa": 222,
    "Tomato": 22,
    "Orange Juice": 112,
    "Beef Steak": 271,
    "Pork Chop": 257,
    "Grapes": 62,
    "Milkshake": 350,
    "Pasta": 200,
    "Orange": 62,
    "Nuts": 180,
    "Cheese": 113,
    "Strawberry": 50,
    "Butter": 102,
    "Rice": 206,
    "Yogurt": 100,
    "Broccoli": 55,
    "Water": 0,
    "Paneer": 265,
    "Salmon": 208,
    "Milk": 103,
    "Coffee": 2,
    "Spinach": 23,
    "Potato": 163,
    "Green Tea": 0,
    "Bread": 79,
    "Chocolate": 208,
    "Chips": 152,
    "Chicken Breast": 165  
}

# --- Load dataset ---
INPUT_FILE = "daily_food_nutrition_dataset.csv"
OUTPUT_FILE = "daily_food_nutrition_filled.csv"

df = pd.read_csv(INPUT_FILE)
df.fillna(0, inplace=True)

# --- Fill missing or zero calories ---
def fill_calories(row):
    name = str(row.get("Food_Item", "")).strip()
    current = row.get("Calories", 0)
    if current == 0 and name in CALORIE_LOOKUP:
        return CALORIE_LOOKUP[name]
    return current

df["Calories"] = df.apply(fill_calories, axis=1)

# --- Save cleaned version ---
df.to_csv(OUTPUT_FILE, index=False)
print(f"✅ Saved cleaned dataset to {OUTPUT_FILE}")
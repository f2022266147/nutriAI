# app.py

from flask import Flask, request, jsonify
import pickle
import pandas as pd
import numpy as np
from typing import Tuple, List

app = Flask(__name__)

# ——————————————————————————
# 1) Load models & unified meals
# ——————————————————————————

# Calorie predictor
with open("calorie_predictor_best.pkl", "rb") as f:
    calorie_model = pickle.load(f)

# Unified meal list
with open("meals.pkl", "rb") as f:
    meals = pickle.load(f)     # list of dicts

# Put into a DataFrame for easy filtering
df_meals = pd.DataFrame(meals)
# standardize strings
df_meals["slot"] = df_meals["slot"].str.lower()
df_meals["dietary_preference"] = df_meals["dietary_preference"].str.lower()

# Slot‐to‐budget ratios
SLOT_RATIO = {
    "breakfast": 0.25,
    "lunch":     0.35,
    "snack":     0.15,
    "dinner":    0.25
}

# ——————————————————————————
# 2) Helper functions
# ——————————————————————————

def compute_activity_multiplier(level: str) -> float:
    lvl = (level or "").strip().lower()
    return {
        "sedentary":        1.2,
        "lightly active":   1.375,
        "moderate":         1.55,
        "moderately active":1.55,
        "active":           1.725,
        "very active":      1.725
    }.get(lvl, 1.55)

def parse_health_conditions(hc: str) -> Tuple[str,str]:
    item = (hc or "").split(",")[0].strip()
    if "(" in item and ")" in item:
        dt, sev = item.split("(", 1)
        return dt.strip(), sev.split(")",1)[0].strip()
    return item, ""

# ——————————————————————————
# 3) /predict-calories endpoint
# ——————————————————————————

@app.route("/predict-calories", methods=["POST"])
def predict_calories():
    data   = request.get_json(force=True)
    age    = float(data.get("age", 0))
    height = float(data.get("height", 0))
    weight = float(data.get("weight", 0))
    gender = data.get("gender", "")
    goal   = data.get("goal", "")
    wcpw   = float(data.get("weight_change_per_week", 0))
    act    = data.get("activity_level", "")
    hc     = data.get("health_conditions", "")

    activity_multiplier = compute_activity_multiplier(act)
    disease_type, severity = parse_health_conditions(hc)

    df = pd.DataFrame([{
        "Age":                    age,
        "Gender":                 gender,
        "Height_cm":              height,
        "Weight_kg":              weight,
        "ActivityMultiplier":     activity_multiplier,
        "Goal":                   goal,
        "Weight_Change_Per_Week": wcpw,
        "Disease_Type":           disease_type,
        "Severity":               severity
    }])

    cal_pred = float(calorie_model.predict(df)[0])
    return jsonify({"predicted_calories": round(cal_pred, 1)})

# ——————————————————————————
# 4) /meal-plan endpoint
# ——————————————————————————

@app.route("/meal-plan", methods=["POST"])
def meal_plan():
    data = request.get_json(force=True)

    # 1) Predict daily calories
    cal_resp   = predict_calories()
    cal_target = cal_resp.get_json()["predicted_calories"]

    # 2) Read user filters
    diet         = data.get("dietary_preference", "").lower()
    slot         = data.get("slot", "").lower()
    restrictions = data.get("restrictions", [])  # e.g. ["low_sodium","nut_free"]

    # 3) Compute slot-specific calorie target
    ratio      = SLOT_RATIO.get(slot, 0.25)
    slot_target = cal_target * ratio

    # 4) Filter our meal pool
    df = df_meals[
        (df_meals["dietary_preference"] == diet) &
        (df_meals["slot"] == slot)
    ].copy()

    # apply each restriction (e.g. keep only meals that list "low_sodium")
    for r in restrictions:
        df = df[df["restrictions"].apply(lambda lst: r in lst)]

    # 5) Score by closeness to slot_target
    df["cal_diff"] = (df["calories"] - slot_target).abs()
    df = df.nsmallest(5, "cal_diff")

    # 6) Build response
    recommendations = []
    for _, row in df.iterrows():
        recommendations.append({
            "meal_name":      row["name"],
            "calories":       row["calories"],
            "tags":           row["tags"],
            "restrictions":   row["restrictions"],
            "cal_diff":       round(float(row["cal_diff"]), 1)
        })

    return jsonify({
        "daily_calorie_target": cal_target,
        "slot":                 slot,
        "slot_calorie_target":  round(slot_target, 1),
        "recommended_meals":    recommendations
    })

# ——————————————————————————
# 5) Run the app
# ——————————————————————————

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)